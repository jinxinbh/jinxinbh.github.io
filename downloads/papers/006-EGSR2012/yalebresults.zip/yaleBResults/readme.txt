yaleBResults.csv file contains the Illumination Matching results of 38 persons frontal face images from Yale Face Database B and the Extension [Georghiades et al. 2001]. Each line returns top 3 matching results of querying a image of person i in person j's images which are taken under 64 lighting conditions. (i, j = 1,2,��,39,  and i is not equal to j, Nubmer 14 is missing in the database.)

Format of each line: INPUT_IMAGE PERSON_NUMBER OUTPUT_IMAGE1 OUTPUT_IMAGE2 OUTPUT_IMAGE3, which represents input image filename, the number of compared person, filenames of top 3 matching results respectively.

GEORGHIADES, A., BELHUMEUR, P., AND KRIEGMAN, D. 2001. From few to many: Illumination cone models for face recognition under variable lighting and pose. TPAMI 23, 6, 643�C660.
