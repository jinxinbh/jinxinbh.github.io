These 3D models are used in the following paper:

Xin Jin, Shuyun Zhu, Chaoen Xiao, Hongbo Sun, Xiaodong Li, Geng Zhao,Shiming Ge. 3D Textured Model Encryption via 3D Lu Chaotic Mapping. Science China Information Sciences (SCIS), Vol. 60, No.12, pp.122107:1-9, December 2017 . 

Please cite this paper if you use the data.